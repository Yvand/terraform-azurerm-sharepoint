# Description

The AdfsClaimDescription Dsc resource manages claim descriptions in the Federation Service.
