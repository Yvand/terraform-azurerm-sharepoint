# Description

The AdfsOrganization DSC resource manages the ADFS Organization information that is published in
the federation metadata for the Federation Service.
