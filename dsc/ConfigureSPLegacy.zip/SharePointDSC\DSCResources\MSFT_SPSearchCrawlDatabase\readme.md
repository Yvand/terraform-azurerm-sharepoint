# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is responsible for managing crawl databases of a Search topology
and is able to add to and remove databases from the topology.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application is provisioned.
